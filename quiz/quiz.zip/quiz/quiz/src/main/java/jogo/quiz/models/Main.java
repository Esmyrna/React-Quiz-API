package jogo.quiz.models;

public class Main {
    public static void main(String[] args) {

    }
}
